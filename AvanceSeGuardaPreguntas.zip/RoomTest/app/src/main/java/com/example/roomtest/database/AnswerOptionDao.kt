package com.example.roomtest.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.roomtest.dataclass.AnswerOption


@Dao
interface AnswerOptionDao {
    @Query("SELECT * FROM AnswerOption")
    fun getAllAnswerOptions(): List<AnswerOption>

    @Query("SELECT * FROM AnswerOption WHERE id = :answerOptionId")
    fun getAnswerOptionById(answerOptionId: Long): AnswerOption?

    @Query("SELECT * FROM AnswerOption WHERE questionId = :questionId")
    fun getAnswerOptionsForQuestion(questionId: Int): List<AnswerOption>

    @Insert
    fun insertAnswerOption(answerOption: AnswerOption)

    @Update
    fun updateAnswerOption(answerOption: AnswerOption)

    // Add other methods for answerOption-related database operations
}