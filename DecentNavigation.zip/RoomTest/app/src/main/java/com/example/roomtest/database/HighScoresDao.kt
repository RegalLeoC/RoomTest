package com.example.roomtest.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.roomtest.dataclass.HighScores

@Dao
interface HighScoresDao {
    @Query("SELECT * FROM HighScores")
    fun getAllHighScores(): List<HighScores>

    @Query("SELECT * FROM HighScores WHERE userId = :userId")
    fun getHighScoresForUser(userId: Int): List<HighScores>

    @Query("SELECT * FROM HighScores WHERE id = :highScoresId")
    fun getHighScoresById(highScoresId: Long): HighScores?

    @Insert
    fun insertHighScores(highScores: HighScores)

    @Update
    fun updateHighScores(highScores: HighScores)

    // Add other methods for highScores-related database operations
}