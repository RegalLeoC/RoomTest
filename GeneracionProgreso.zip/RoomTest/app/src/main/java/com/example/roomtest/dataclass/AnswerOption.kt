package com.example.roomtest.dataclass

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName="AnswerOption", foreignKeys = [ForeignKey(entity = Question::class, parentColumns = ["id"], childColumns = ["questionId"], onDelete = ForeignKey.CASCADE)])
data class AnswerOption(
    @PrimaryKey val id: Int,
    @ColumnInfo(name = "questionId")
    val questionId: Int, // Foreign key to Question
    val state: String = "Unanswered",
    val optionText: Char

)


