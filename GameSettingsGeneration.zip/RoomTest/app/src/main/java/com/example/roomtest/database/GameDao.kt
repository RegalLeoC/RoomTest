package com.example.roomtest.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.roomtest.dataclass.Game_settings


@Dao
interface GameDao {
    @Query("SELECT * FROM Game_settings")
    fun getAllGames(): List<Game_settings>

    @Query("SELECT * FROM Game_settings WHERE userId = :userId")
    fun getGamesForUser(userId: Int): List<Game_settings>

    @Query("SELECT * FROM Game_settings WHERE id = :gameId")
    fun getGameById(gameId: Long): Game_settings?

    @Query("SELECT * FROM Game_settings WHERE id = :settingsId LIMIT 1")
    suspend fun getGameSettingsById(settingsId: Int): Game_settings?

    @Query("SELECT * FROM Game_settings WHERE userId = :userId")
    suspend fun getGameSettingsByUserId(userId: Int): Game_settings?

    @Insert
    suspend fun insertGameSettings(gameSettings: Game_settings)

    @Insert
    fun insertGame(game: Game_settings)

    @Update
    fun updateGame(game: Game_settings)

    // Add other methods for game-related database operations
}