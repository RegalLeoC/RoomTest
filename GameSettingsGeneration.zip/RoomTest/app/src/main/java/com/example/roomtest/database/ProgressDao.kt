package com.example.roomtest.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.roomtest.dataclass.Progress

@Dao
interface ProgressDao {
    @Query("SELECT * FROM Progress")
    fun getAllProgresses(): List<Progress>

    @Query("SELECT * FROM Progress WHERE id = :progressId")
    fun getProgressById(progressId: Long): Progress?

    @Query("SELECT * FROM Progress WHERE userId = :userId")
    fun getProgressForUser(userId: Int): List<Progress>

    @Insert
    fun insertProgress(progress: Progress)

    @Update
    fun updateProgress(progress: Progress)

    // Add other methods for progress-related database operations
}