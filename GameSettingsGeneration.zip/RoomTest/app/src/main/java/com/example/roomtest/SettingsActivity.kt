package com.example.roomtest

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.example.roomtest.database.MyAppDatabase
import com.example.roomtest.dataclass.Game_settings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SettingsActivity : AppCompatActivity() {

    private lateinit var db: MyAppDatabase
    private var activeUserId: Int = 0
    private var gameSettings: Game_settings? = null
    private lateinit var seekBarQuestions: SeekBar
    private lateinit var switchHints: SwitchCompat
    private lateinit var checkBoxTheme1: CheckBox
    private lateinit var checkBoxTheme2: CheckBox
    private lateinit var checkBoxTheme3: CheckBox
    private lateinit var checkBoxTheme4: CheckBox
    private lateinit var checkBoxTheme5: CheckBox
    private lateinit var checkBoxTheme6: CheckBox
    private lateinit var spinnerDifficulty: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        db = MyAppDatabase.getDatabase(applicationContext)

        // Initialize UI components
        seekBarQuestions = findViewById(R.id.seekBarQuestions)
        switchHints = findViewById(R.id.switchHints)

        GlobalScope.launch(Dispatchers.IO) {
            activeUserId = db.userDao().getActiveUserId() ?: -1
            // Check if game settings exist for the active user
            checkGameSettings()
            // Set up UI components
            withContext(Dispatchers.Main) {
                setupUI()
            }
        }
    }

    private fun checkGameSettings() {
        GlobalScope.launch(Dispatchers.IO) {
            // Check if game settings exist for the active user
            gameSettings = db.gameDao().getGameSettingsByUserId(activeUserId)

            // If game settings don't exist, create new ones
            if (gameSettings == null) {
                var settingsId: Int? = null
                do {
                    val randomId = (1000..9999).random() // Generate random ID
                    val existingSettings = db.gameDao().getGameSettingsById(randomId)
                    if (existingSettings == null) {
                        // If settings with this ID doesn't exist, insert new settings with this ID
                        val newSettings = Game_settings(id = randomId, userId = activeUserId)
                        db.gameDao().insertGameSettings(newSettings)
                        settingsId = randomId
                    }
                } while (settingsId == null)

                // Retrieve the newly inserted game settings
                gameSettings = db.gameDao().getGameSettingsById(settingsId)
            }
        }
    }


    private fun setupUI() {

        checkBoxTheme1 = findViewById(R.id.checkBoxTheme1)
        checkBoxTheme2 = findViewById(R.id.checkBoxTheme2)
        checkBoxTheme3 = findViewById(R.id.checkBoxTheme3)
        checkBoxTheme4 = findViewById(R.id.checkBoxTheme4)
        checkBoxTheme5 = findViewById(R.id.checkBoxTheme5)
        checkBoxTheme6 = findViewById(R.id.checkBoxTheme6)
        spinnerDifficulty = findViewById(R.id.spinnerDifficulty)


        // Set up SeekBar for selecting number of questions
        seekBarQuestions.progress = gameSettings?.numQuestions ?: 5 // Default to 5 if game settings are null
        seekBarQuestions.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                // Update number of questions in game settings when SeekBar progress changes
                gameSettings?.numQuestions = progress
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Set up Switch for enabling/disabling hints
        switchHints.isChecked = gameSettings?.clues ?: true // Default to true if game settings are null
        switchHints.setOnCheckedChangeListener { _, isChecked ->
            // Update hints status in game settings when Switch state changes
            gameSettings?.clues = isChecked
        }

        // You can similarly set up other UI components (checkboxes, spinner) here
        // For example:
        // Set up checkboxes for themes
        checkBoxTheme1.isChecked = gameSettings?.topic1 ?: true
        checkBoxTheme2.isChecked = gameSettings?.topic2 ?: true
        checkBoxTheme3.isChecked = gameSettings?.topic3 ?: true
        checkBoxTheme4.isChecked = gameSettings?.topic4 ?: true
        checkBoxTheme5.isChecked = gameSettings?.topic5 ?: true
        checkBoxTheme6.isChecked = gameSettings?.topic6 ?: true

        // Set up spinner for difficulty
        val difficultyLevels = arrayOf("Easy", "Normal", "Hard")
        spinnerDifficulty.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, difficultyLevels)
        spinnerDifficulty.setSelection(difficultyLevels.indexOf(gameSettings?.difficulty ?: "Normal"))
    }

}
