package com.example.roomtest.dataclass

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName = "Game_settings")
data class Game_settings(
    @PrimaryKey val id: Int,
    @ColumnInfo(name = "userId")
    val userId: Int?, // Foreign key to User
    val difficulty: String = "Normal",
    var numQuestions: Int = 10,
    val topic1: Boolean = true,
    val topic2: Boolean = true,
    val topic3: Boolean = true,
    val topic4: Boolean = true,
    val topic5: Boolean = true,
    val topic6: Boolean = true,
    var clues: Boolean = true
)