package com.example.roomtest.dataclass

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(tableName="Progress", foreignKeys = [ForeignKey(entity = Game_settings::class, parentColumns = ["id"], childColumns = ["gameId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = Question::class, parentColumns = ["id"], childColumns = ["questionId"], onDelete = ForeignKey.CASCADE),
    ForeignKey(entity = User::class, parentColumns = ["id"], childColumns = ["userId"], onDelete = ForeignKey.CASCADE)])
data class Progress(
    @PrimaryKey val id: Int,
    @ColumnInfo(name = "gameId")
    val gameId: Int, // Foreign key to Game_settings
    @ColumnInfo(name = "questionId")
    val questionId: Int, // Foreign key to Question
    @ColumnInfo(name = "userId")
    val userId: Int, // Foreign key to User
    val score: Int = 0,
    val clues: Boolean
)